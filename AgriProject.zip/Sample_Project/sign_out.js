function sign_out()
{
    alert("Succefully sign out");
}
function sign_in(){
    alert("Sucessfully Signed In!")
}

